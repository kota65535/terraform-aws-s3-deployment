const c="awesome",n=[1,2,3],o={unicorns:c,abc:n};export{n as abc,o as default,c as unicorns};
